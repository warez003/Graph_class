﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            button1.Visible = false;
            this.Text = "Табулирование функций";
            label1.Text = "X0";
            label1.Font = new Font("Times new roman", 14, FontStyle.Regular);
            label2.Text = "XM";
            label2.Font = new Font("Times new roman", 14, FontStyle.Regular);
            label3.Text = "XD";
            label3.Font = new Font("Times new roman", 14, FontStyle.Regular);
            groupBox1.Text = "Действие";
            groupBox1.Font = new Font("Times new roman", 14, FontStyle.Regular);
            radioButton1.Text = "MIN";
            radioButton1.Font = new Font("Times new roman", 14, FontStyle.Regular);
            radioButton2.Text = "MAX";
            radioButton2.Font = new Font("Times new roman", 14, FontStyle.Regular);
            button1.Text = "Вычислить";
            button1.Font = new Font("Times new roman", 14, FontStyle.Regular);
            label4.Text = " ";
            radioButton4.Text = "Кол-во Y > 0";
            radioButton5.Text = "Сумма Y > 0";
            radioButton6.Text = "Произведение Y > 0 и Y < 0";

            button1.Click += Button1_Click;

            textBox1.TextChanged += TextBox1_TextChanged;
            textBox2.TextChanged += TextBox2_TextChanged;
            textBox3.TextChanged += TextBox3_TextChanged;
        }

        private void TextBox3_TextChanged(object sender, EventArgs e) {
            if (textBox1.Text.Length > 0 && textBox2.Text.Length > 0 && textBox3.Text.Length > 0) {
                button1.Visible = true;
            }
        }

        private void TextBox2_TextChanged(object sender, EventArgs e) {
            if (textBox1.Text.Length > 0 && textBox2.Text.Length > 0 && textBox3.Text.Length > 0) {
                button1.Visible = true;
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e) {
            if (textBox1.Text.Length > 0 && textBox2.Text.Length > 0 && textBox3.Text.Length > 0) {
                button1.Visible = true;
            }
        }

        private void Button1_Click(object sender, EventArgs e) {

            this.chart1.Series[0].Points.Clear();
            double x0 = Convert.ToDouble(textBox1.Text);
            double xd = Convert.ToDouble(textBox3.Text); 
            double xm = Convert.ToDouble(textBox2.Text);

            Graph g1 = new Graph(x0, xm, xd);
            MessageBox.Show(Convert.ToString($"X: {g1.X}, D: {g1.D}"));
            if (x0 > 1.5) {
                for (; g1.X < g1.XM; g1.X += g1.D) {
                    g1.A = 2.5; g1.T1 = 3; g1.B = 6; g1.T2 = g1.T1 - 1; g1.C = -30;
                    g1.Fx();
                }
            }
            this.chart1.Series[0].Points.AddXY(g1.X, g1.Fx());
            label5.Text = g1.View;
            label5.Visible = true;

           /* while(g1.X < g1.XM) {
                 g1.X += g1.D;

                if (x0 > 1.5)
                {
                    y = 2.5 * Math.Pow(x0, 3) + 6 * Math.Pow(x0, 2) - 30;
                    label5.Text = "y = 2.5 * x^3 + 6 * x^2 - 30";
                    label5.Visible = true;
                    ArrY.Add(y);
                }
                else if ( x0 >= 0 || x0 <= 1.5)
                {
                    y = x0 + 1;
                    label5.Text = "y = x + 1";
                    label5.Visible = true;
                    ArrY.Add(y);
                }
                else if (x0 < 0)
                {
                    y = x0;
                    label5.Text = "y = x";
                    label5.Visible = true;
                    ArrY.Add(y);
                }
           */

            if (radioButton1.Checked) {
                label4.Visible = true;
                label4.Text = "Min = " + Convert.ToString(g1.OfMin());
                label4.Font = new Font("Times new roman", 14, FontStyle.Regular);
            } else if(radioButton2.Checked) {
                label4.Visible = true;
                label4.Text = "Max = " + Convert.ToString(g1.OfMax());
                label4.Font = new Font("Times new roman", 14, FontStyle.Regular);
            } else if (radioButton4.Checked) {
                label4.Visible = true;
                label4.Text = $"Значений  y>0 : {Convert.ToString(g1.YThenZero())}";
                label4.Font = new Font("Times new roman", 14, FontStyle.Regular);
            } else if (radioButton5.Checked) {
                label4.Visible = true;
                label4.Text = $"Cумма значений y>0 : {Convert.ToString(g1.SumThenZero())}";
                label4.Font = new Font("Times new roman", 14, FontStyle.Regular);
            } else if (radioButton6.Checked) {
                label4.Visible = true;
                label4.Text = $"Произведение значений y>0 : {Convert.ToString(g1.Mult(true))}";
                label4.Font = new Font("Times new roman", 14, FontStyle.Regular);
            }

        }
    }
}
