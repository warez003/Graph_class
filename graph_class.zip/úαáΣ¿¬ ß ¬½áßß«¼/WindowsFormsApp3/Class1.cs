﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3 {
    class Graph {
        private double f;
        private double x;
        private  double xM;
        private  double d;
        private  double a;
        private  double b;
        private  double c;
        private  double t1;
        private  double t2;
        private string view;

        public double F { get; }
        public double X { get; set; }
        public double XM { get; set; }
        public double D { get; set; }
        public double A { get; set; }
        public double B { get; set; }
        public double C { get; set; }
        public double T1 { get; set; }
        public double T2 { get; set; }
        public string View { get; }

        public Graph() {
            x = -2; xM = 3; d = 0.5; a = 1; b = 1; c = 0; t1 = 2; t2 = t1-1;
        }
        public Graph(double x, double xM, double d, double a, double b, double c, double t1, double t2) {
            this.x = x;
            this.xM = xM;
            this.d = d;
            this.a = a;
            this.b = b;
            this.c = c;
            this.t1 = t1;
            this.t2 = t2;
        }
        public Graph(double x, double xM, double d) {
            this.x = x;
            this.xM = xM;
            this.d = d;
            a = 1; b = 1; c = 0; t1 = 2; t2 = t1 - 1;
        }

        public double Mult(bool isThenZero) {

            double mult = 1;

            for (; x < xM; x += d) {
                if (isThenZero == true) {
                    if (Fx() > 0) {
                        mult *= Fx();
                    }
                } else if (isThenZero == false) {
                    if (Fx() < 0) {
                        mult *= Fx();
                    }
                }
            }

            return mult;
        }

        public double Mult() {

            double mult = 1;

            for (; x < xM; x += d) {
                mult *= Fx();
            }

            return mult;
        }

        public int SumThenZero() {

            int sum = 0;

            for (; x < xM; x += d) {
                if (Fx() > 0) {
                    sum += Convert.ToInt32(Fx());
                }
            }

            return sum;
        }

        public int YThenZero() {

            int count = 0;

            for (; x < xM; x += d) {
                if (Fx() > 0) {
                    count++;
                }
            }

            return count;
        }

        public double OfMin() {

            double min = double.MaxValue;

            for (; x < xM; x += d) {
                if (Fx() < min) {
                    min = Fx();
                }
            }

            return min;
        }

        public double OfMax() {

            double max = double.MinValue;

            for (; x < xM; x += d) {
                if (Fx() < max) {
                    max = Fx();
                }
            }

            return max;
        }

        public double Fx() {
            f = a * Math.Pow(x, t1) + b * Math.Pow(x, t2) + c;
            view = $"{a} * {Math.Pow(x, t1)} + {b} * {Math.Pow(x, t2)} + {c}";
            return f;
        }
    }
}
