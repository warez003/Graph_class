﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3 {
    class Class1 {
        private double f, x, xM, d;

        public double F { get;  set; }

        public Class1() {
            x = -2; xM = 3; d = 0.5;
        }
        public Class1(double x, double xM, double d) {
            this.x = x;
            this.xM = xM;
            this.d = d;
        }

        public void Fx () {



            for (; x < xM; x += d) {
            }
        }
    }
}
